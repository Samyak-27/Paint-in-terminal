//h file for print_statements.c
#ifndef PRINT_STATEMENTS_H
#define PRINT_STATEMENTS_H

// Function declarations for printing statements
void print_canvas(const canvas *c);

#endif // PRINT_STATEMENTS_H
