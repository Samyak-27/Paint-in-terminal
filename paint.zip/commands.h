//h file for commands.c
#ifndef COMMANDS_H
#define COMMANDS_H
#include "canvas.h"

//Function declarations
void execute_command(canvas *c, char *command);

#endif // COMMANDS_H